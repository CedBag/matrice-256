# MATRICE-256 (FaNet v4.0)
**Réseau Neuro-Symbolique d'Architecture Fâ**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-%23EE4C2C.svg?style=flat&logo=PyTorch&logoColor=white)](https://pytorch.org/)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](#)

*Ce projet est soumis au Concours de cas d'application créative en IA pour les jeunes africains (2026).*

**Matrice-256 (FaNet)** est le premier framework d'Intelligence Artificielle Neuro-Symbolique au monde intégrant un biais inductif culturel africain directement dans sa fonction de perte neuronale. Fondé sur la combinatoire du Fâ (géomancie béninoise), FaNet projette les données dans un espace de 256 attracteurs sémantiques, produisant des diagnostics explicables, robustes au bruit et conformes par design aux normes de protection de la vie privée (RGPD/HIPAA). 

📖 **[Consulter le Livre Blanc Scientifique (Whitepaper)](docs/whitepaper_matrice256.md)**  

---

## 🏆 Validation Scientifique (8 Tests Exigeants)

FaNet v4.0 a été validé sur 8 bancs d'essai scientifiques, surpassant les modèles de référence (Random Forest, Gradient Boosting) sur les critères de souveraineté et d'explicabilité :

| Test | Résultat Clé | Statut |
|---|---|---|
| **T1 — Robustesse au Bruit** | Surpasse Random Forest à 50% de bruit (96.1% vs 95.7%) | ✅ |
| **T2 — Cross-Validation K=10** | Accuracy 97.50%, Rappel 100% | ✅ |
| **T3 — OOD Généralisation** | Rappel 100% inter-domaine (RF : 92%) | ✅ |
| **T4 — Calibration Clinique** | ECE 14.71% — meilleur du benchmark | ✅ |
| **T5 — Régression Fintech** | MAE 143 FCFA — viable Agri-Fintech | ✅ |
| **T6 — IoT Temporel LSTM** | F1 54%, Rappel 97.4% — architecture temporelle validée | ✅ |
| **T7 — MIA / Vie Privée** | AUC 0.5261 — Conforme RGPD Art. 25 & HIPAA (RF non-conforme) | ✅ |
| **T8 — Energy Score CO₂** | **-67.8% d'énergie d'inférence vs RF (40 nWh/inférence)** | ✅ |

---

## 🧠 L'Architecture Neuro-Symbolique

FaNet v4.0 est une architecture mathématique hybride :
1. **TorchFaEmbedding** : Encodeur combinatoire qui projette les données dans l'espace des 16 Clés Fondamentales via attention croisée.
2. **FaImbalanceLoss** : Perte informée par l'ontologie pénalisant le réseau s'il viole l'équilibre Yin/Yang des Kpolis.
3. **Module Temporel (LSTM)** : Traitement natif des séries temporelles (capteurs IoT).
4. **Air-Gapped par Design** : Aucune donnée ne sort du processeur local, assurant la souveraineté.

---

## 🚀 Démarrage Rapide

### 1. Environnement Local
```bash
git clone https://github.com/VOTRE_ORGA/Matrice-256.git
cd Matrice-256
pip install -r requirements.txt
```

### 2. L'API Développeur (Zéro Bullshit)
```python
from bokono.ml.torch_network import TorchFaNet

# Initialise le réseau (v4.0 supporte la compilation JIT)
model = TorchFaNet(n_features=8, hidden_dim=32, n_outputs=1)

# Entraînement avec pénalité ontologique (lambda_fa)
model.fit(X_train, y_train, epochs=30, lambda_fa=0.2, compile=True)

# Inférence avec explicabilité native
probability, interpretation = model.predict(X_patient)
print(interpretation[0]["ontological_state"]) # ex: STATE_003
print(interpretation[0]["system_polarity"])   # FAUSSE ROUTE / FAVORABLE
```

---

## 📊 Preuves de Concept (PoC)

Exécutez les démos interactives pour voir le modèle en action :

1. **Diagnostic Médical (Santé) :**
   ```bash
   python demo_health_fanet.py
   ```
2. **Analyse de Sols (Agriculture) :**
   ```bash
   python demo_agri_fanet.py
   ```

---

## 🔐 Propriété & Souveraineté

- **Conformité RGPD** : Le test Membership Inference Attack (Test 7) prouve que FaNet ne mémorise pas les données d'entraînement.
- **Souveraineté** : Modèle léger (50 000 paramètres), exécutable sur CPU/Edge (Raspberry Pi), sans dépendance au cloud.

**Propriété Intellectuelle (PI)** : `Copyright © 2026 - Cedoque BAGBONON. Strictement Propriétaire. La base de données Fâ et l'encodeur sont des secrets industriels protégés.`
