import math
import torch
import torch.nn as nn
from torch.nn import functional as F

# ==========================================
# ROPE (Rotary Positional Embeddings)
# ==========================================
def precompute_freqs_cis(dim: int, end: int, theta: float = 10000.0):
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2)[: (dim // 2)].float() / dim))
    t = torch.arange(end, device=freqs.device, dtype=torch.float32)
    freqs = torch.outer(t, freqs)
    return torch.cos(freqs), torch.sin(freqs)

def apply_rotary_emb(x, freqs_cos, freqs_sin):
    x1, x2 = x[..., 0::2], x[..., 1::2]
    freqs_cos = freqs_cos.unsqueeze(0).unsqueeze(2) 
    freqs_sin = freqs_sin.unsqueeze(0).unsqueeze(2)
    
    y1 = x1 * freqs_cos - x2 * freqs_sin
    y2 = x1 * freqs_sin + x2 * freqs_cos
    
    out = torch.empty_like(x)
    out[..., 0::2] = y1
    out[..., 1::2] = y2
    return out

# ==========================================
# 1. ATTENTION LATENTE MULTI-TÊTES (MLA) & FÂ
# ==========================================
class FaCausalSelfAttention(nn.Module):
    """
    Intègre le MLA (Multi-head Latent Attention de DeepSeek) pour compresser le KV Cache
    et le modulateur géomantique Fâ.
    """
    def __init__(self, config):
        super().__init__()
        assert config.n_embd % config.n_head == 0
        
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.head_size = config.n_embd // config.n_head
        
        # --- MLA (Multi-head Latent Attention) ---
        # Au lieu de projeter K et V (2 * n_embd), on compresse dans un espace latent
        self.kv_latent_dim = config.n_embd // 4  # Compression massive (1/4)
        self.kv_down = nn.Linear(config.n_embd, self.kv_latent_dim, bias=config.bias)
        self.kv_norm = nn.LayerNorm(self.kv_latent_dim) # Stabilisation du vecteur compressé
        self.kv_up = nn.Linear(self.kv_latent_dim, 2 * config.n_embd, bias=config.bias)
        
        # Les Queries (Q) restent normales pour capturer les nuances
        self.q_proj = nn.Linear(config.n_embd, config.n_embd, bias=config.bias)
        self.c_proj = nn.Linear(config.n_embd, config.n_embd, bias=config.bias)
        self.attn_dropout = nn.Dropout(0.1) # [AUDIT FIX] Anti-overfitting sur longs entraînements
        
        # --- L'INNOVATION NEURO-SYMBOLIQUE (Fâ) ---
        # 16 Clés Mères
        self.fa_keys = nn.Parameter(torch.randn(1, self.n_head, 16, self.head_size) * (1.0 / math.sqrt(self.head_size)))
        self.fa_gate = nn.Parameter(torch.zeros(1)) 

        self.register_buffer("bias", torch.tril(torch.ones(config.block_size, config.block_size))
                                     .view(1, 1, config.block_size, config.block_size))

    def forward(self, x, freqs_cos, freqs_sin):
        B, T, C = x.size()

        # Calcul des Queries
        q = self.q_proj(x).view(B, T, self.n_head, self.head_size)
        
        # Calcul de K et V via la compression Latente (MLA) + Normalisation
        kv_latent = self.kv_down(x)
        kv_latent = self.kv_norm(kv_latent)
        k, v = self.kv_up(kv_latent).split(self.n_embd, dim=2)
        k = k.view(B, T, self.n_head, self.head_size)
        v = v.view(B, T, self.n_head, self.head_size).transpose(1, 2) # (B, nh, T, hs)
        
        # RoPE sur Q et K
        q = apply_rotary_emb(q, freqs_cos[:T], freqs_sin[:T])
        k = apply_rotary_emb(k, freqs_cos[:T], freqs_sin[:T])
        
        q = q.transpose(1, 2) # (B, nh, T, hs)
        k = k.transpose(1, 2) # (B, nh, T, hs)

        # 1. Attention Classique
        att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
        att = att.masked_fill(self.bias[:,:,:T,:T] == 0, float('-inf'))
        att_weights = F.softmax(att, dim=-1)
        att_weights = self.attn_dropout(att_weights) # [AUDIT FIX] Régularisation de l'attention
        
        # 2. Attention Ontologique (Fâ) -> Génère aussi le signal de Routage !
        fa_att = (q @ self.fa_keys.transpose(-2, -1)) * (1.0 / math.sqrt(self.head_size))
        fa_att_weights = F.softmax(fa_att, dim=-1) # (B, nh, T, 16)
        
        # Modulation Fâ
        fa_modulated_v = (fa_att_weights @ self.fa_keys) # (B, nh, T, hs)
        gate = torch.sigmoid(self.fa_gate)
        fused_v = v * (1 - gate) + (v * fa_modulated_v) * gate
        
        y = att_weights @ fused_v # (B, nh, T, hs)
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        
        # Extraction du signal de routage (Moyenne des probabilités Fâ sur toutes les têtes)
        # Format: (B, T, 16)
        fa_router_probs = fa_att_weights.mean(dim=1) 
        
        return self.c_proj(y), fa_router_probs


# ==========================================
# 2. EXPERT FÂ & MoFE (Mixture of Fâ Experts)
# ==========================================

# Les 16 Kpoli (Clés Mères du Fâ) encodées en binaire.
# Chaque liste de 4 bits représente les 4 lignes géomantiques :
#   1 = trait continu (Yang/ouvert/expansion)
#   0 = trait discontinu (Yin/fermé/contraction)
# Cette table est le CŒUR de l'innovation : elle transforme
# la cosmologie Fâ en structure mathématique mesurable.
KPOLI_SIGNATURES = [
    [1, 1, 1, 1],  #  0: Ogbé     — Pure Lumière (expansion totale)
    [0, 0, 0, 0],  #  1: Oyèkú    — Pure Nuit (contraction totale)
    [1, 1, 0, 0],  #  2: Iwori    — Feu intérieur (haut ouvert, bas fermé)
    [0, 0, 1, 1],  #  3: Odi      — Terre profonde (haut fermé, bas ouvert)
    [1, 0, 1, 0],  #  4: Irosun   — Alternance Yang (oscillation positive)
    [0, 1, 0, 1],  #  5: Owonrin  — Alternance Yin (oscillation négative)
    [1, 0, 0, 0],  #  6: Obara    — Étincelle (yang minimal)
    [0, 0, 0, 1],  #  7: Okanran  — Germe (yang naissant)
    [1, 1, 1, 0],  #  8: Ogunda   — Tranchant (yang dominant, yin ancré)
    [0, 1, 1, 1],  #  9: Osa      — Marée montante (yin vers yang)
    [0, 0, 1, 0],  # 10: Ika      — Noyau (yang isolé au centre)
    [0, 1, 0, 0],  # 11: Oturupon — Fissure (yang isolé haut)
    [1, 0, 1, 1],  # 12: Otura    — Vision (yang dispersé dominant)
    [1, 1, 0, 1],  # 13: Irẹtẹ   — Fondation (yang structuré)
    [1, 0, 0, 1],  # 14: Osẹ      — Pont (yang aux extrémités)
    [0, 1, 1, 0],  # 15: Ofun     — Cœur (yang au centre)
]

def _init_kpoli_expert(expert, kpoli_index, n_embd):
    """
    Initialise un expert MLP selon la signature binaire de son Kpoli.
    
    Mécanisme : La dimension cachée (hidden_dim) est divisée en 4 quadrants.
    Pour chaque quadrant, le bit correspondant du Kpoli détermine le SIGNE
    du biais d'initialisation :
      - Bit = 1 (Yang) → biais positif (tendance à amplifier le signal)
      - Bit = 0 (Yin)  → biais négatif (tendance à filtrer le signal)
    
    L'amplitude est proportionnelle au nombre de bits Yang (énergie du Kpoli).
    
    Résultat : 16 experts mathématiquement DISTINCTS dès l'initialisation,
    chacun avec une "personnalité" structurelle dérivée du Fâ.
    """
    code = KPOLI_SIGNATURES[kpoli_index]
    yang_count = sum(code)
    
    # Énergie proportionnelle au yang : de 0.005 (pur Yin) à 0.025 (pur Yang)
    energy = 0.005 + 0.005 * yang_count
    
    hidden_dim = expert.c_fc.weight.size(0)
    quadrant = hidden_dim // 4
    
    with torch.no_grad():
        for q in range(4):
            s, e = q * quadrant, (q + 1) * quadrant
            sign = 1.0 if code[q] == 1 else -1.0
            
            # Biais structurel sur la couche d'expansion
            expert.c_fc.weight.data[s:e] += sign * energy
            # Biais miroir atténué sur la couche de projection
            expert.c_proj.weight.data[:, s:e] += sign * energy * 0.5


class FaExpert(nn.Module):
    """ Un petit expert mathématique classique (MLP) """
    def __init__(self, config):
        super().__init__()
        # On divise la taille du MLP par 2 pour garder une taille mémoire frugale, 
        # car on a 16 experts maintenant.
        hidden_dim = 2 * config.n_embd 
        self.c_fc    = nn.Linear(config.n_embd, hidden_dim, bias=config.bias)
        self.gelu    = nn.GELU()
        self.c_proj  = nn.Linear(hidden_dim, config.n_embd, bias=config.bias)

    def forward(self, x):
        return self.c_proj(self.gelu(self.c_fc(x)))

class FaMixtureOfExperts(nn.Module):
    """
    Réseau MoE piloté par les 16 énergies du Fâ.
    Seuls les Top-2 experts sont activés par token pour une vitesse fulgurante.
    """
    def __init__(self, config):
        super().__init__()
        self.num_experts = 16 # Les 16 Clés Mères
        self.top_k = 2        # On active 2 experts maximum
        self.experts = nn.ModuleList([FaExpert(config) for _ in range(self.num_experts)])
        
        # Initialisation sémantique : chaque expert reçoit la signature de son Kpoli
        for i, expert in enumerate(self.experts):
            _init_kpoli_expert(expert, i, config.n_embd)

    def forward(self, x, router_probs):
        # router_probs arrive directement de l'Attention (B, T, 16)
        B, T, C = x.size()
        N = B * T  # Nombre total de tokens dans le batch
        
        # On trouve les 2 meilleurs experts (Top-K) et leurs poids respectifs
        top_k_probs, top_k_indices = torch.topk(router_probs, self.top_k, dim=-1)
        top_k_probs = top_k_probs / top_k_probs.sum(dim=-1, keepdim=True)
        
        x_flat = x.view(N, C)
        flat_indices = top_k_indices.view(N, self.top_k)
        flat_probs = top_k_probs.view(N, self.top_k)
        
        # [AUDIT FIX] Matrice de poids agrégés par expert via scatter_add.
        # Corrige Bug #1 : si un token sélectionne le même expert 2 fois,
        # les poids sont correctement additionnés au lieu de crasher.
        expert_weight_matrix = torch.zeros(N, self.num_experts, device=x.device, dtype=x.dtype)
        expert_weight_matrix.scatter_add_(1, flat_indices, flat_probs)
        
        final_out = torch.zeros_like(x_flat)
        
        # Dispatch vers chaque expert (seuls les tokens concernés sont calculés)
        for i, expert in enumerate(self.experts):
            w_i = expert_weight_matrix[:, i]  # (N,) poids agrégé pour cet expert
            mask = w_i > 0
            if mask.any():
                expert_out = expert(x_flat[mask])
                final_out[mask] += expert_out * w_i[mask].unsqueeze(-1)
        
        # --- LOAD BALANCING LOSS (L_aux) ---
        tokens_per_expert = (expert_weight_matrix > 0).sum(dim=0).float()
        f_i = tokens_per_expert / (N * self.top_k)
        P_i = router_probs.view(-1, self.num_experts).mean(dim=0)
        self.l_aux = self.num_experts * torch.sum(f_i * P_i)
        
        return final_out.view(B, T, C)

# ==========================================
# 3. BLOC & MODÈLE GLOBAL
# ==========================================
class FaTransformerBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = FaCausalSelfAttention(config)
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mofe = FaMixtureOfExperts(config) # Remplace le vieux MLP

    def forward(self, x, freqs_cos, freqs_sin):
        # L'Attention retourne le texte (y) ET le signal de routage Fâ
        y, fa_router_probs = self.attn(self.ln_1(x), freqs_cos, freqs_sin)
        x = x + y
        
        # Le Routeur MoFE utilise la décision géomantique pour allumer les experts
        x = x + self.mofe(self.ln_2(x), fa_router_probs)
        return x

class FaNetConfig:
    def __init__(self, vocab_size=32000, block_size=256, n_layer=12, n_head=12, n_embd=768, bias=False):
        self.vocab_size = vocab_size
        self.block_size = block_size
        self.n_layer = n_layer
        self.n_head = n_head
        self.n_embd = n_embd
        self.bias = bias

class FaNetSLM(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config

        self.transformer = nn.ModuleDict(dict(
            wte = nn.Embedding(config.vocab_size, config.n_embd),
            drop = nn.Dropout(0.1),
            h = nn.ModuleList([FaTransformerBlock(config) for _ in range(config.n_layer)]),
            ln_f = nn.LayerNorm(config.n_embd),
        ))
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)
        self.transformer.wte.weight = self.lm_head.weight # Weight Tying

        head_size = config.n_embd // config.n_head
        freqs_cos, freqs_sin = precompute_freqs_cis(head_size, config.block_size * 2) 
        self.register_buffer("freqs_cos", freqs_cos, persistent=False)
        self.register_buffer("freqs_sin", freqs_sin, persistent=False)

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx, targets=None):
        b, t = idx.size()
        assert t <= self.config.block_size, f"Contexte max dépassé."
        
        tok_emb = self.transformer.wte(idx)
        x = self.transformer.drop(tok_emb)

        # On passe les fréquences RoPE aux blocs et on cumule la Load Balancing Loss
        aux_loss = 0.0
        for block in self.transformer.h:
            x = block(x, self.freqs_cos, self.freqs_sin)
            aux_loss = aux_loss + block.mofe.l_aux
            
        x = self.transformer.ln_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            ce_loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1), ignore_index=-1)
            # Ajout de l'équilibre Fâ (Load Balancing) avec un coefficient alpha de 0.01
            loss = ce_loss + 0.01 * aux_loss

        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, top_k=None):
        for _ in range(max_new_tokens):
            idx_cond = idx if idx.size(1) <= self.config.block_size else idx[:, -self.config.block_size:]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / temperature
            
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float('Inf')
                
            probs = F.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, idx_next), dim=1)
            
        return idx
